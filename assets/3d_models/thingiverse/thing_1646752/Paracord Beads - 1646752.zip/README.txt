Paracord Beads by sLpFhaWK on Thingiverse: https://www.thingiverse.com/thing:1646752

Summary:
Couple easy to print Paracord Beads