Miyuka Beads Sorting Box by 3Deddy on Thingiverse: https://www.thingiverse.com/thing:3117835

Summary:
Specially designed sorting box for those very little beads to keep them sorted even when the box is shaken. Also rounded bottom corners so you can easily pick those tiny beads from the bottom. UPDATE 1-12-2018: Sorry for al you who downloaded earlier... The lid and box hinges did not match.. I uploaded the wrong versions... Thanks to eljer0n!Have fun printing and please leave me a Like if you like it! 