Bicycle Spoke Beads by jonmonaghan on Thingiverse: https://www.thingiverse.com/thing:12625

Summary:
Go Retro.