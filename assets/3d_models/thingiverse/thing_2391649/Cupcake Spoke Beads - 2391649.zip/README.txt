Cupcake Spoke Beads by 3DPRINTINGWORLD on Thingiverse: https://www.thingiverse.com/thing:2391649

Summary:
Cup Cake Spoke BeadsIf you want to print in two colors the cup ends at 7mm high.