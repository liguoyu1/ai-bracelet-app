Beads Tray by DataMouse on Thingiverse: https://www.thingiverse.com/thing:3316941

Summary:
A beads tray for making beads objects.Contains 8 trays which are labled by "A" to "H" and an extra round tray in middle.